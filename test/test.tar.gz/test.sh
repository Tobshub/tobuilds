#!/usr/bin/bash

echo HELLO WORLD $@
